<a href="https://docs.google.com/uc?export=download&id=1_RErvmnEj8uEpxcfHxhJ6wpgoBO6c3N1">DESCARGAR Soporte de Pago</a>
